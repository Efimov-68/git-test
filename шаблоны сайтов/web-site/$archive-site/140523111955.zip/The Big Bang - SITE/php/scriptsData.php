<?php
	include_once (dirname(dirname(__FILE__)).'/CONFIG.php');
	echo 'var twitterName = "'.$twitter_name.'";';
	echo 'var facebook_statistic_page = "'.$facebook_statistic_page.'";';
	
	echo 'var Year =  '.$year.';';
    echo 'var Month  = '.$month.';';
    echo 'var Day = '.$day.';';
    echo 'var Hour = '.$hour.';';
    echo 'var Minutes = '.$minutes.';';
    echo 'var Second = '.$second.';';
?>