Please only use this for your reference. This folder was not developed with the intention that you upload this to your server as it is not a theme dependancy. The purpose of these documents is to help you read the custom code I wrote in the compressed JavaScript folder. If this confuses you, simply ignore this folder.

Thanks :)